const express = require('express')
const router = express.Router()//路由对象
// 导入数据库对象
const db = require('./db')
//返回所有的待办事项 
router.get('/todos', (req, res) => {
    db.query('select * from todo', (err, results) => {
        if (err) return console.log(err.message);
        res.send({
            status: 0,
            message: '查询成功',
            data: results
        })
    })
})
//根据id获取一个待办事项
router.get('/todos/:id', (req, res) => {
    // results -> 不管查询有几个结果，都是数组
    db.query('select * from todo where id = ?', [req.params.id], (err, results) => {
        if (err) return console.log(err.message);
        res.send({
            status: 0,
            message: '查询成功',
            data: results[0]
        })
    })
})
// 新增待办事项
router.post('/todos', (req, res) => {
    var name = req.body.name
    db.query('insert into todo (name) values (?)', [name], (err, results) => {
        if (err) return console.log(err.message);
        // 查询得到的是数组 其他操作（新增、删除、更新）返回的是影响行数
        // affectedRows 影响行数是1
        if (results.affectedRows === 1) {
            res.send({
                status: 0,
                message: '新增成功'
            })
        } else {
            res.send({
                status: 1,
                message: '新增失败'
            })
        }
    })
})
// 修改事项 
router.put('/todos/:id', (req, res) => {
    var name = req.body.name
    db.query('update todo set name = ? where id = ?', [name, req.params.id], (err, results) => {
        if (err) return console.log(err.message);
        if (results.affectedRows === 1) {
            res.send({
                status: 0,
                message: '修改成功'
            })
        } else {
            res.send({
                status: 1,
                message: '修改失败'
            })
        }
    })
})

// 删除事项
router.delete('/todos/:id', (req, res) => {
    db.query('delete from todo where id = ?', [req.params.id], (err, results) => {
        if (err) return console.log(err.message);
        if (results.affectedRows === 1) {
            res.send({
                status: 0,
                message: '删除成功'
            })
        } else {
            res.send({
                status: 1,
                message: '删除失败'
            })
        }
    })
})

module.exports = router

// ?id=1 -> req.query.id
// /1 -> req.params.id

// get 获取
// post 新增
// delete 删除
// put 修改


// router.method(url,callback)
