const express = require('express')
const app = express()
// 解决跨域问题
const cors = require('cors')
app.use(cors())
//接收post数据必须用这个内置中间件 req.body 
app.use(express.urlencoded({ extended: false }))
// 路由代码
const router = require('./router')
app.use(router)
app.listen(3000, () => console.log('服务器开启成功'))

// 中间件要写在路由的前面 要不然没效果

// 报错了怎么办




// sql语句
// select * from todo
// select * from todo where id = 1
// insert into todo (name) values ('事项名字')
// update todo set name = '名字' where id = 1
// delete from todo where id = 1 