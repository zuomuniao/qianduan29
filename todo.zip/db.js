const mysql = require('mysql2')
const connection = mysql.createConnection({
    host: 'localhost',//域名或ip
    user: 'root',//数据库的账号
    password: 'root',//数据库密码
    database: 'mydb'//用哪个数据库 
})
module.exports = connection//把数据库对象导出去