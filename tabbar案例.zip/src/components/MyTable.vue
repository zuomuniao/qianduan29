<template>
  <table class="table table-bordered table-stripped">
    <!-- 表格标题区域 -->
    <thead>
      <tr>
        <th>#</th>
        <th>商品名称</th>
        <th>价格</th>
        <th>标签</th>
        <th>操作</th>
      </tr>
    </thead>
    <!-- 表格主体区域 -->
    <tbody>
      <tr v-for="(item, index) in data" :key="index">
        <td>{{ item.id }}</td>
        <td>{{ item.goods_name }}</td>
        <td>{{ item.goods_price }}</td>
        <td>
          <input
            type="text"
            class="tag-input"
            v-model="item.inputValue"
            v-if="item.inputVisible"
            v-focus
            @keyup.enter="add(item)"
            @blur="add(item)"
            @keyup.esc="item.inputValue = ''"
          />
          <span
            class="badge badge-pill badge-primary"
            v-else
            @click="item.inputVisible = true"
            >+ New Tag</span
          >
          <span
            v-for="(item, index) in item.tags"
            :key="index"
            class="badge badge-pill badge-primary"
            >{{ item }}</span
          >
        </td>
        <td>
          <button class="btn btn-danger btn-sm" @click="$emit('del', item.id)">
            删除
          </button>
        </td>
      </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  props: {
    data: {
      type: Array,
      required: true
    }
  },
  name: 'MyTable',
  methods: {
    add (obj) {
      //这块不需要子传父 因为我们添加是给对象的某一项属性加东西，没有改变对象的地址
      obj.tags.push(obj.inputValue)
      obj.inputValue = ''
      obj.inputVisible = false
    }
  }
}


// var arr = [2,3,4]
// arr.forEach(function(item1,index1){

// })
</script>


<style scoped lang="less">
.my-goods-list {
  .badge {
    margin-right: 5px;
  }
}
.badge {
  margin-right: 10px;
  padding: 10px;
}

.tag-input {
  width: 80px;
}
</style>