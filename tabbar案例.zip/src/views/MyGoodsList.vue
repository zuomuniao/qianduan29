<template>
  <MyTable :data="list" @del="delFn"></MyTable>
</template>

<script>
// 其他代码出问题了，直接看控制台有没有红色的，研究红色
// ajax出错了 1. 先看控制台 2. 再看network(网络 Fetch/XHR 载荷参数 请求报文 响应报文) 
import MyTable from '../components/MyTable.vue'
export default {
  created () {
    this.getList()
  },
  data () {
    return {
      list: []
    }
  },
  methods: {
    getList () {
      this.$axios({ url: '/api/goods' }).then(res => {
        this.list = res.data.data
      })
    },
    delFn (id) {
      //根据id找索引
      var index = this.list.findIndex(item => item.id === id)
      this.list.splice(index, 1)
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: { MyTable }
}
</script>

<style scoped lang="less">
</style>
