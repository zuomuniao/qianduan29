<template>
  <div>
    <MyHeader title="tabbar案例"></MyHeader>
    <component :is="active" class="main"></component>
    <MyTabBar
      :list="tabList"
      :active="active"
      @update-active="active = $event"
    ></MyTabBar>
  </div>
</template>

<script>
import MyHeader from './components/MyHeader.vue'
import MyTabBar from './components/MyTabBar.vue'
import MyGoodsList from './views/MyGoodsList.vue'
import MyGoodsSearch from './views/MyGoodsSearch.vue'
import MyUserInfo from './views/MyUserInfo.vue'
export default {
  created () { },
  data () {
    return {
      tabList: [
        {
          iconText: "icon-shangpinliebiao",
          text: "商品列表",
          componentName: "MyGoodsList"
        },
        {
          iconText: "icon-sousuo",
          text: "商品搜索",
          componentName: "MyGoodsSearch"
        },
        {
          iconText: "icon-user",
          text: "我的信息",
          componentName: "MyUserInfo"
        }
      ],
      active: 'MyGoodsList'
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: { MyHeader, MyTabBar, MyGoodsList, MyGoodsSearch, MyUserInfo }
}
</script>

<style scoped lang='less'>
.main {
  margin-top: 45px;
  margin-bottom: 50px;
}
</style>
