4 个阶段 8 个钩子函数
4 个单词 create mount update destroy 前 后

1. 初始化 beforeCreate 数据准备好了 created
   - created 一般在这里面发送 ajax 请求
2. 挂载 beforeMount 视图同步成功 mounted
   - mounted 可以操作 DOM
3. 更新 只要 data 中数据变了，就会发生更新操作 beforeUpdate 视图和更新之后数据同步成功了 updated
   - updated 可以拿到更新之后视图 DOM
   - 用得不多，可以用$nextTick() 数据更新了，既可以在updated中拿到最新的数据，也可以在$nextTick 的回调函数中拿最新的数据，实际中$nextTick 更常用
4. 销毁 实例被销毁，一般在项目中是配合 v-if 来使用 beforeDestroy destroyed
   - beforeDestroy 实际中都是在这个里面做清理工作（当前组件中定时器、事件绑定、事件总线 eventBus 清理）

实际中三个用得最多：created mounted beforeDestroy

注意事项：

1. 初始化、挂载、销毁只会执行一次 更新会执行多次（只要 data 变了，就会触发）
2. 哪个组件被销毁了，它身上的 beforeDestory 才会执行
3. 每个组件都有自己的 8 个钩子函数

https://www.sunxiaoning.com/usr/uploads/2018/07/3510381174.png

template 内置 vue 组件 ： 当我们需要一个包裹性标签，但是渲染之后又不想要的时候，可以用这个

props 更好的写法

1. <组件 a="abc" :b="abc" :c="'abc'" d :e="false" >
2. 不建议驼峰式 <组件 my-title></组件> background-color 只有js才能写驼峰式


props:['abc']

props:{
   abc:{
      type:String,
      required:true  
   },
   bcd:{
      type:Number,
      default:100
      default:()=>({name:'zs'}),
      default:()=>[2,3,4],
      validator:function(value){
         return true 验证成功
         return false 失败
      }
   }
}


要看的文档
1. https://cn.vuejs.org/v2/guide/components-props.html#Prop-%E9%AA%8C%E8%AF%81
2. https://cn.vuejs.org/v2/guide/components-props.html#%E4%BC%A0%E9%80%92%E9%9D%99%E6%80%81%E6%88%96%E5%8A%A8%E6%80%81-Prop
3. https://cn.vuejs.org/v2/guide/conditional.html#%E5%9C%A8-lt-template-gt-%E5%85%83%E7%B4%A0%E4%B8%8A%E4%BD%BF%E7%94%A8-v-if-%E6%9D%A1%E4%BB%B6%E6%B8%B2%E6%9F%93%E5%88%86%E7%BB%84

