<template>
  <div>
    <button @click="flag = false">按钮</button>
    <MyCeshi v-if="flag"></MyCeshi>
  </div>
</template>

<script>
import MyCeshi from './components/MyCeshi.vue'
export default {
  created () { },
  data () {
    return {
      flag: true
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {
    MyCeshi
  },

}
</script>

<style scoped>
</style>
