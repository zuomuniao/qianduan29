<template>
  <div>测试组件</div>
</template>

<script>
var timer = null;
var fn = function () {
  console.log(1234);
}
export default {
  created () {
    //有时候组件是自动播放的轮播图
    timer = setInterval(() => {
      console.log(123);
    }, 1000)
    // EventBus.$on('自定义事件类型',callback)
    window.addEventListener('mousemove', fn)
  },
  data () {
    return {

    }
  },
  methods: {
    fn () {
      this.a = 100
    }
  },

  computed: {},
  watch: {

  },
  filters: {},
  components: {},
  //组件被销毁，清理现场 收尾工作 1. 定时器关闭 2. 事件绑定解除 3. 事件总线自定义事情移除
  beforeDestroy () {//实例还是可以用的 一般用这个 临死前
    console.log('销毁前');
    clearInterval(timer)
    // EventBus.$off('自定义事件类型')
    window.removeEventListener('mousemove', fn)
  },
  destroyed () {//实例没有了
    console.log('销毁之后');
  }
}



</script>

<style scoped>
</style>
