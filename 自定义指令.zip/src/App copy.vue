<template>
  <div>
    <my-table :data="list" :headers="headers">
      <template v-slot="scope">
        <td>{{ scope.row.id }}</td>
        <td>{{ scope.row.name }}</td>
        <td>{{ scope.row.done }}</td>
      </template>
    </my-table>
  </div>
</template>

<script>
// 自定义指令的使用场景：需要重复在多个页面中同样的操作DOM
import MyComp from './components/MyComp.vue'
import MyTable from './components/MyTable.vue'
export default {
  mounted () {

  },
  components: { MyComp, MyTable },
  data () {
    return {
      list: [
        { id: 1, name: '吃饭', done: true },
        { id: 2, name: '睡觉', done: false },
        { id: 3, name: '打豆豆', done: true }
      ],
      headers: ['id', '任务名', '是否完成']
    }
  }
}
</script>

<style scoped>
</style>
