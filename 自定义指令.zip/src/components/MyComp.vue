<template>
  <div>
    <p>
      <slot :flag="flag"></slot>
    </p>
  </div>
</template>

<script>
// 子组件有一个数据要展示出来，但是不知道怎么呈现 ，这个时候 
// 1. 这块东西不确定 -> 插槽
// 2. 数据要传给外面 -> 作用域插槽
// 基本上不可能自己封装带有作用域插槽的组件 我们一般只会使用，不用封装
export default {
  created () { },
  data () {
    return {
      flag: true
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
