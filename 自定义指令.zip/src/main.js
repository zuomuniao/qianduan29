import Vue from 'vue'
import App from './App.vue'
import 'bootstrap/dist/css/bootstrap.css'
Vue.config.productionTip = false
// v-color
Vue.directive('color', {
  //el是指令所在的dom元素
  // 插入钩子 指令所在的标签插入到页面DOM树就会执行 只会执行一次
  inserted (el, binding) {
    console.log(binding);
    el.style.color = binding.value
  },
  //更新 页面中只要有data中数据更新了就会执行
  update (el, binding) {
    console.log(123);
  }
})


Vue.directive('check', {
  //需要在页面一打开的时候操作DOM 只会执行一次
  inserted () { },
  //实时校验 只要数据变了就校验 
  // el->span
  // binding.value -> username 
  update (el, binding) {//数据更新的时候需要操作DOM 执行多次
    if (binding.value.length < 5) {
      el.style.color = 'red'
      el.innerHTML = '非法'
    } else {
      el.style.color = 'green'
      el.innerHTML = '合法'
    }
  }
})
new Vue({
  render: h => h(App),
}).$mount('#app')
