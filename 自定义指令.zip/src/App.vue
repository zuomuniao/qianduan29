<template>
  <div>
    <!-- myColor是一个变量 在data中 -->
    <!-- <p v-color="myColor">123</p>
    <input type="text" v-model="msg" /> -->
    <input type="text" placeholder="用户名" v-model="username" />
    <span v-check="username"></span>
  </div>
</template>

<script>
export default {
  created () { },
  data () {
    return {
      username: ''
      // myColor: 'blue',
      // msg: 'hello'
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {},
  directives: {}
}
</script>

<style scoped>
</style>
