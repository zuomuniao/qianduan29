// 这个文件就是webpack配置的时候入口entry 
import Vue from 'vue'
import App from './App.vue'
Vue.config.productionTip = false
new Vue({
    // render: function (createElement) {
    //     return createElement('h1', 'hello world')
    // }
    render: h => h(App)
}).$mount('#app')