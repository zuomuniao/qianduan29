<template>
  <div>
    <!-- 属性绑定 -->
    <!-- v-bind:属性名="data中的变量名" -->
    <!-- v-bind:href后面跟的是变量 -->
    <!-- href后面跟的是字符串 -->
    <!-- 变量是蓝色的 字符串橘黄色 -->
    <a v-bind:href="url">去百度</a>
    <a :href="url">去百度</a>
    <!-- <a href="https://baidu.com">去百度</a> -->
    <img v-bind:src="url1" width="40" v-bind:title="title" />
    <img :src="url1" width="40" :title="title" />
    <!-- <img src="https://cn.vuejs.org/images/logo.svg" alt="" /> -->
  </div>
</template>

<script>
// 热更新
// 只要没效果，第一时间看控制台有没有红色报错
export default {
  data () {
    return {
      url: 'https://baidu.com',
      url1: 'https://cn.vuejs.org/images/logo.svg',
      title: '标题1111'
    }
  }
}
</script>

<style scoped>
</style>
