// 这是配置文件，配置文件做了任何改动一定要重启项目
// config 配置
// 凡是带有config，并且一般在项目的根目录是配置文件
const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false//暂时关闭掉eslint报错提示
})
