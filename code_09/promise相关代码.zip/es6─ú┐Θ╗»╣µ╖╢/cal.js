export const add = (a, b) => a + b
export const substract = (a, b) => a - b
