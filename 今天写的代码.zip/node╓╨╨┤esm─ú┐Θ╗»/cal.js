export const add = (a, b) => a + b
export const substract = (a, b) => a - b
export const multiple = (a, b) => a * b
export const divide = (a, b) => a / b

// export default 默认导出
// export 按需导出
