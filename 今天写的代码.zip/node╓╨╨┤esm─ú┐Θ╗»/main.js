import add from './add.js'
// console.log(add(2, 3))

// const fs = require('fs')
// import fs from 'fs'

// import { add as add1  , substract } from './cal.js'

// 第一次手写 第二次CV

// import * as obj from './cal.js'
import './ceshi.js'

// import Vue from 'vue'
// import {mapMutations} from 'vuex'
// import './reset.css'
