export default function (a, b) {
  return a + b
}
