// 同一个js模块可以既有按需导出也有默认导出 开一家店专卖店 扩展各种业务 主营业务
// 按需导出
// export const a = 1
// export const b = 2
// export function fn() {
//   console.log(123)
// }
// export default 200
