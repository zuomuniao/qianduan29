// 默认导出 export default 当前模块只有一个东西需要导出 写二个就错了
// 按需导出 export  当前模块有一堆东西要导出，但是用不是非得全部用，而是想用哪个就导入哪个
export default (a, b) => a + b
