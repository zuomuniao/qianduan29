// 1. mode 模式
// 2. entry 入口
// 3. output 出口
// 4. plugins
// 5. loader 处理不是以.js结尾的文件 翻译器
// webpack本身功能很弱，通过各种插件让功能变强，通过各各种loader让webpack懂各种语言
// less -> less-loader
// css -> css-loader
// 现在有一个html我们想放到dist中 插件
const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
module.exports = {
  mode: 'development', //开发模式
  entry: './src/main.js', //入口
  output: {
    //出口
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js',
  },
  plugins: [
    //插件
    // 1. 把public/index.html拷贝到dist中 2. 自动引入打包好的bundle.js 3. 设置页面title 标题
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, './public/index.html'),
      title: '黑马头条',
    }),
    //抽取css到一个单独的文件
    new MiniCssExtractPlugin(),
  ],
  module: {
    //rules 规则 数组 -> 数组中每一项是一个对象，用于处理一种文件类型
    rules: [
      // 只要是文件后缀多一处，rules数组中多一项
      {
        test: /\.css$/i, // reg.test 匹配 i忽略大小写
        //use 使用 用什么处理
        //从右往左执行 先用css-loader识别出来这块是css代码 然后再用style-loader插入到head标签 style
        use: [MiniCssExtractPlugin.loader, 'css-loader'],
      },
      {
        test: /\.less$/i,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'less-loader'],
      },
      {
        // webpack 将按照默认条件，自动地在 resource 和 inline 之间进行选择：小于 8kb 的文件，将会视为 inline 模块类型，否则会被视为 resource 模块类型
        test: /\.(png|gif|jpg|jpeg)$/i,
        type: 'asset',
        parser: {
          dataUrlCondition: {
            // 临界点 比这个值大就是单独的图片
            maxSize: 893,
          },
        },
      },
      {
        // preset 预设 第二次去一家餐馆 老板问你是不是不用选，用上一次选的点的餐 套餐
        test: /\.m?js$/,
        exclude: /(node_modules|bower_components)/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
          },
        },
      },
    ],
  },
}

// 入口 src/index.js
// 出口 dist/main.js
// 模板html文件 public/index.html

// 1. mode 模式 devleopment production
// 2. entry

// npm i @vue/cli -g （不能用yarn）windows旗舰版 家庭版 定制版
// 如果失败了 npm cache clean --force 再试一次 （有时候下一半失败了，可能再也安装不上去
// 断网开热点 重试
