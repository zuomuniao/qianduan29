import $ from 'jquery'
import './css/1.css'
import './css/2.less'
$('li:even').css('color', 'red')
$('li:odd').css('color', 'blue')

import gif from './assets/1.gif'
// webapi 案例不用看 轮播图不用看
// jquery基本用不上 除非特别旧项目维护
var img = document.createElement('img')
img.src = gif
document.body.append(img) //放最后面

// webpack只会处理一种es6,就是翻译import,export default，其他的不管
// 加载器 处理 .js结尾的
// es6 -> es5 js进行降级
// 项目用不上ie 根据项目目标客户用哪些浏览器
// browerslistrc这个文件后面项目会有，告诉webpack我们的项目将来打包之后用户主要是用的是哪些浏览器 ie9 const let kfc 肯德基
const add = (a, b) => a + b
console.log(add)
