<template>
  <div>
    <p v-if="age >= 18">成年</p>
    <p v-else>未成年</p>
    <hr />
    <p v-if="score >= 80">优秀</p>
    <p v-else-if="score >= 60">及格</p>
    <p v-else>不及格</p>

    <hr />
    <button @click="flag = !flag">按钮</button>
    <!-- v-if和v-show呈现效果是一模一样的，但是实现的原理不一样 -->
    <!-- v-if 如果是一开始flag值是true,变成false,直接把DOM对象销毁 
    v-show 如果是一开始flag值是true,变成false display:none  -->

    <!-- v-if 如果是一开始flag值是false,直接不创建 什么也不做
    v-show 如果是一开始flag值是false,还是会创建，只不过 display:none -->

    <!-- 看使用场景 -->
    <!-- 一般来说，v-if 有更高的切换开销，而 v-show 有更高的初始渲染开销 -->
    <!-- 1. 原理 v-if 创建和销毁元素 v-show display:none 
    2. 使用场景  如果需要非常频繁地切换，则使用 v-show 较好；如果在运行时条件很少改变，则使用 v-if 较好  -->
    <div
      v-if="flag"
      style="width: 100px; height: 100px; background: pink; margin-bottom: 20px"
    ></div>

    <div
      v-show="flag"
      style="width: 100px; height: 100px; background: blue"
    ></div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      age: 19,
      score: 70,
      flag: false
    }
  },
}


// var score = 70
// if(score >= 80){

// }else if(score >= 60){

// }
</script>

<style scoped>
</style>
