import Vue from 'vue'
import App from './App.vue'
// 如果一个样式在所有的组件中全部要用 在main.js
// import 'bootstrap/dist/css/bootstrap.css'
Vue.config.productionTip = false

// 全局过滤器
Vue.filter('reverse', function (val) {
  return val.split('').reverse().join('')
})

import moment from 'moment'
Vue.filter('dateformat', function (val) {
  return moment(val).format('YYYY年MM月DD日')
})


new Vue({
  render: h => h(App),
}).$mount('#app')



// v-bind 
// v-on 
// v-model 
// v-if 
// v-show 
// v-text 
// v-html 
// v-for 

// 修饰符
// 1. 事件 stop prevent once 
// 2. 按键 enter esc 
// 3. 表单 number trim lazy 

// 相似的元素vue区分不出来 就地复用

// 有id用id，没有id用索引