<template>
  <div id="app">
    <div class="container">
      <!-- 顶部框模块 -->
      <div class="form-group">
        <div class="input-group">
          <h4>品牌管理</h4>
        </div>
      </div>

      <!-- 数据表格 -->
      <table class="table table-bordered table-hover mt-2">
        <thead>
          <tr>
            <th>编号</th>
            <th>资产名称</th>
            <th>价格</th>
            <th>创建时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in list" :key="item.id">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>

            <!-- 如果价格超过100，就有red这个类 -->
            <!-- 类名 动态绑定的 -->
            <!-- :class="变量"
            :class="[变量,变量]"
            :class="{类名:布尔值}" -->
            <td :class="{ red: item.price > 100 }">{{ item.price }}</td>
            <td>{{ item.time | dateformat }}</td>
            <!-- 有id用id，没有id用索引 -->
            <td><a href="#" @click.prevent="del(item.id)">删除</a></td>
          </tr>
        </tbody>
        <!-- 
        <tfoot >
          <tr>
            <td colspan="5" style="text-align: center">暂无数据</td>
          </tr>
        </tfoot>
            -->
      </table>

      <!-- 添加资产 -->
      <form class="form-inline">
        <div class="form-group">
          <div class="input-group">
            <input
              v-model.trim="name"
              type="text"
              class="form-control"
              placeholder="资产名称"
            />
          </div>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <div class="form-group">
          <div class="input-group">
            <input
              v-model.trim.number="price"
              type="text"
              class="form-control"
              placeholder="价格"
            />
          </div>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <!-- 阻止表单提交 -->
        <!-- button有默认值 type="submit" -->
        <button class="btn btn-primary" @click.prevent="add">添加资产</button>
        <!-- <button class="btn btn-primary" type="button" @click="add">添加资产</button> -->
      </form>

      <p>商品总价:{{ list.reduce((sum, item) => (sum += item.price), 0) }}元</p>
      <p>商品总价:{{ total }}元</p>
      <p>均价：{{ average }}元</p>
      <p>均价：{{ average }}元</p>
      <p>均价：{{ average }}元</p>
      <p>均价：{{ average1() }}元</p>
      <p>均价：{{ average1() }}元</p>
      <p>均价：{{ average1() }}元</p>
    </div>

    <p>{{ msg | reverse | abc("~") }}</p>
    <p>{{ firstName + " " + lastName }}</p>
    <p>{{ fullName }}</p>
    <!-- v-model是双向数据绑定的 -->
    <!-- 计算属性是只读的,由其他数据算出来的 -->
    <input type="text" v-model="fullName" />

    <hr />
    <input type="text" v-model="msg" />
    <input type="text" v-model="msg1" />

    <hr />
    <button @click="fullName = '马 化腾'">改名字</button>
    姓: <input type="text" v-model="firstName" /> 名:
    <input type="text" v-model="lastName" />
    <br />
    姓名: <input type="text" v-model="fullName" />
  </div>
</template>

<script>

// 什么时候用methods，什么时候用computed 
// 1. 事件的回调函数用methods 
// 2. template视图中需要一个数据，这个数据在data没有，但是可以通过data中的数据计算得到 

// 计算属性也可以用methods来写，只不过要多了个小括号，但是不推荐，因为methods没有缓存 
// 有缓存性能高一点

// data,methods,computed这几个东西，名字不能一样
// data中没有这个数据，但是可以通过data中数据计算得到 
// 计算属性的使用场景：当我们发现插值表达式逻辑过于复杂的时候就可以用计算属性来替换
// find,findIndex,every,some,map,reduce,forEach,filter
// 表单元素用v-model绑定

// 有要渲染的数据，但是这个数据要格式化一下
// 过滤器的使用场景：1. 时间处理 2. 货币
export default {
  data () {
    return {
      name: "", // 名称
      price: 0, // 价格
      list: [
        { id: 100, name: "外套", price: 199, time: new Date('2010-08-12') },
        { id: 101, name: "裤子", price: 34, time: new Date('2013-09-01') },
        { id: 102, name: "鞋", price: 25.4, time: new Date('2018-11-22') },
        { id: 103, name: "头发", price: 19900, time: new Date('2020-12-12') }
      ],
      msg: 'hello world',
      firstName: '马',
      lastName: '云'
    };
  },
  methods: {
    add () {
      // 数据驱动视图 不用操作DOM
      // 表单数据校验
      if (this.name === '' || this.price === '' || this.price === 0) return alert('表单数据不能为空或0')
      // var id = this.list[this.list.length-1].id+1 
      // var id = this.list.slice(-1)[0].id + 1
      var id = this.list.length === 0 ? 101 : this.list[this.list.length - 1].id + 1
      var time = new Date()//当前时间
      //对象的简写 属性名和值相同可以写一个
      // var obj = { id: id, name: this.name, price: this.price, time: time }
      var obj = { id, name: this.name, price: this.price, time }
      this.list.push(obj)
      //清理表单input
      this.name = this.price = ''
    },
    del (id) {
      //通过id找索引 findIndex 
      var index = this.list.findIndex(item => item.id === id)
      this.list.splice(index, 1)
    },
    average1 () {
      // console.log('方法调用了');
      return this.total / this.list.length
    }
  },
  // 先局部后全局 很少会用局部 因为局部没法复用
  filters: {
    reverse (val) {
      return val.split('').reverse().join('')
    },
    abc (val, char) {
      return val + char.repeat(10)
    }
  },
  computed: {
    // 计算属性
    //fullName不是后面的函数，是后面的函数的返回值 不是方法 是属性 
    // fullName () {
    //   return this.firstName + ' ' + this.lastName
    // },
    fullName: {
      get () {
        return this.firstName + ' ' + this.lastName
      },
      set (newVal) {
        var arr = newVal.split(' ')
        this.firstName = arr[0]
        this.lastName = arr[1]
      }
    },
    total () {
      return this.list.reduce((sum, item) => sum += item.price, 0)
    },
    average () {
      // console.log('计算属性被执行了');
      return this.total / this.list.length
    },
    // 计算属性是只读的 不能直接修改
    // msg1 () {
    //   return this.msg.split('').reverse().join('')
    // }
    // 计算属性的完整写法
    msg1: {
      //设置 给它一个新的值
      set (newVal) {
        this.msg = newVal.split('').reverse().join('')
      },
      //获取 取值
      get () {
        return this.msg.split('').reverse().join('')
      }
    }
  }
};


// var a = 100
// console.log(a);//get 
// a = 200;//set 这个200就是newVal 


// function fn(){
//   return 100;
// }

// var a = fn()

</script>

<style >
.red {
  color: red;
}
</style>