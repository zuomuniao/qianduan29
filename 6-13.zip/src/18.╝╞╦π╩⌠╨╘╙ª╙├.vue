<template>
  <div>
    <span>全选:</span>
    <!-- 单个复选框值是布尔值 -->
    <input type="checkbox" v-model="all" />
    <button @click="change">反选</button>
    <ul>
      <li v-for="(item, index) in arr" :key="index">
        <input type="checkbox" v-model="item.c" />
        <span>{{ item.name }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
// 只要是数组就要遍历 v-for 
// 只要是表单,就要用v-model 
// 有id用id,没有id用索引
// 如果模板中的要的数据在data中没有,但是可以通过data中数据计算得到,就可以用计算属性
// 默认计算属性是只读的,如果想实现可以修改,要用完整写法
export default {
  data () {
    return {
      arr: [
        {
          name: "猪八戒",
          c: true,
        },
        {
          name: "孙悟空",
          c: false,
        },
        {
          name: "唐僧",
          c: false,
        },
        {
          name: "白龙马",
          c: false,
        },
      ],
    };
  },
  computed: {
    // all () {
    //   // every 只有数组每一项都满足这个条件,返回值就是true,否则就是false 
    //   return this.arr.every(item => item.c)
    // }
    all: {
      get () {
        return this.arr.every(item => item.c)
      },
      set (newVal) {//newVal只可能是true或false 
        this.arr.forEach(item => item.c = newVal)
      }
    }
  },
  methods: {
    change () {
      this.arr.forEach(item => item.c = !item.c)
    }
  }
};
</script>