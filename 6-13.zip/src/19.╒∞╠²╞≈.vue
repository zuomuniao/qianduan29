<template>
  <div id="app">
    <div class="container">
      <!-- 顶部框模块 -->
      <div class="form-group">
        <div class="input-group">
          <h4>品牌管理</h4>
        </div>
      </div>

      <!-- 数据表格 -->
      <table class="table table-bordered table-hover mt-2">
        <thead>
          <tr>
            <th>编号</th>
            <th>资产名称</th>
            <th>价格</th>
            <th>创建时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in list" :key="item.id">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td :class="{ red: item.price > 100 }">{{ item.price }}</td>
            <td>{{ item.time | dateformat }}</td>
            <!-- 有id用id，没有id用索引 -->
            <td><a href="#" @click.prevent="del(item.id)">删除</a></td>
          </tr>
        </tbody>
        <!-- 
        <tfoot >
          <tr>
            <td colspan="5" style="text-align: center">暂无数据</td>
          </tr>
        </tfoot>
            -->
      </table>

      <!-- 添加资产 -->
      <form class="form-inline">
        <div class="form-group">
          <div class="input-group">
            <input
              v-model.trim="name"
              type="text"
              class="form-control"
              placeholder="资产名称"
            />
          </div>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <div class="form-group">
          <div class="input-group">
            <input
              v-model.trim.number="price"
              type="text"
              class="form-control"
              placeholder="价格"
            />
          </div>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <!-- 阻止表单提交 -->
        <!-- button有默认值 type="submit" -->
        <button class="btn btn-primary" @click.prevent="add">添加资产</button>
      </form>

      <p>商品总价:{{ total }}元</p>
      <p>均价：{{ average }}元</p>
    </div>

    <hr />
    <input type="text" v-model="msg" />
    <input type="text" v-model="obj.username" />
  </div>
</template>

<script>
// 一堆的方法,都要在方法最后一行要一行同样的代码 只要list数据变了,就要同步到本地存储
// 侦听器 可以实现对data,computed中的数据进行侦听 监视 只要数据改变了,侦听器里面回调就会执行
export default {
  data () {
    return {
      name: "", // 名称
      price: 0, // 价格
      // 数据就不能写死，要来自本地存储中
      list: JSON.parse(localStorage.getItem('list')) || [],
      msg: 'hello',
      obj: {
        username: 'zs'
      }
    };
  },
  methods: {
    add () {
      // 数据驱动视图 不用操作DOM
      // 表单数据校验
      if (this.name === '' || this.price === '' || this.price === 0) return alert('表单数据不能为空或0')
      // var id = this.list[this.list.length-1].id+1 
      // var id = this.list.slice(-1)[0].id + 1
      var id = this.list.length === 0 ? 101 : this.list[this.list.length - 1].id + 1
      var time = new Date()//当前时间
      //对象的简写 属性名和值相同可以写一个
      // var obj = { id: id, name: this.name, price: this.price, time: time }
      var obj = { id, name: this.name, price: this.price, time }
      this.list.push(obj)
      //清理表单input
      this.name = this.price = ''


      //数据持久化
      // localStorage.setItem('list', JSON.stringify(this.list))
    },
    del (id) {
      //通过id找索引 findIndex 
      var index = this.list.findIndex(item => item.id === id)
      this.list.splice(index, 1)

      //数据持久化
      // localStorage.setItem('list', JSON.stringify(this.list))
    },
    average1 () {
      // console.log('方法调用了');
      return this.total / this.list.length
    }
  },
  // 先局部后全局 很少会用局部 因为局部没法复用
  filters: {
    reverse (val) {
      return val.split('').reverse().join('')
    },
    abc (val, char) {
      return val + char.repeat(10)
    }
  },
  computed: {
    total () {
      return this.list.reduce((sum, item) => sum += item.price, 0)
    },
    average () {
      return this.total === 0 ? 0 : this.total / this.list.length
    },
  },
  watch: {
    //对list进行侦听 监视 只要list变了，就持久化到本地存储
    list (newVal) {
      localStorage.setItem('list', JSON.stringify(newVal))
    },
    // list:{
    //   handler(newVal){}
    // }
    // msg (newVal, oldVal) {
    //   console.log(newVal, oldVal);
    // },
    // // 当我们监听的是data中对象的时候,如果我们改变了对象的属性,不会触发监听回调函数
    // // obj (newVal, oldVal) {
    // //   console.log(123);
    // // }
    // // 监听对象中某属性 
    // // 思路一： '对象.属性'(newVal,oldVal){} newVal 最新的值 oldVal上一次的值
    // // 可以监听data中的对象的属性
    // 'obj.username': function (newVal, oldVal) {
    //   console.log(newVal, oldVal);
    // },
    // // 思路二：用深度监听
    // // 对象必须深度监听 写法类似计算属性完整写法
    // obj: {
    //   handler (newVal, oldVal) {
    //     console.log(newVal, oldVal);
    //   },
    //   deep: true,//深度修饰
    //   immediate: true//立即修饰
    // }
  }
};

// var obj = {
//   'background-color':'pink'
// }



// var obj = { name: 'zs' }
//如果前面是空值，就不执行后面
//短路运算的语法糖  webpack可以直接用高级语法
// vue只能用于ie9以上，低版本用不了
// console.log(obj?.name);
// console.log(obj && obj.name);

// var obj = {
//   a: {
//     b: 1
//   }
// }

// console.log(obj?.a?.b);

// // obj&&obj.a&&obj.a.b 
</script>

<style >
.red {
  color: red;
}
</style>