<template>
  <div>
    <p>{{ msg }}</p>
    <p>{{ 1 + 1 }}</p>
    <p>{{ 18 > 17 ? "真" : "假" }}</p>
    <p>{{ a }}</p>
    <p>{{ b }}</p>
    <p>{{ c }}</p>
    <p>{{ d }}</p>
    <p>{{ e }}</p>
    <p>{{ f }}</p>
    <p>{{ g }}</p>
  </div>
</template>

<script>
// template中不能写this.属性 或 this.方法名 写了反而错了 但是在js中必须写this 
export default {
  // 组件的名字 方便我们可以在控制台找到这个组件
  name: 'App',
  //data必须是一个函数的写法，函数返回一个对象
  //data中的数据就可以在template中使用，用插值表达式
  data () {
    return {
      msg: 'hello world',
      a: 100,
      b: true,
      c: null,//这个不显示
      d: undefined,//不显示
      e: [2, 3, 4],
      f: {
        a: 2,
        b: 3
      },
      g: ''//不显示
    }
  }
}

// var a = 1 
// var b = a 
// var c = 1+1 
// var d = function(){}
// var e = d()
// var f = 18>17?true:false \



// function data(){
//   return {
//     a:1 
//   }
// }

// var obj1 = data()
// var obj2 = data()


// console.log({} === {});
</script>

<style scoped>
</style>


