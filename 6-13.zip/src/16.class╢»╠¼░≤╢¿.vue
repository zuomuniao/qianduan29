<template>
  <div>
    <!-- 第一种 只有一个类名  :class="data中变量" -->
    <div :class="class1"></div>
    <!-- 第二种写法 二个类名 :class="[data中变量1,data中变量2]" -->
    <div :class="[class1, class2]"></div>
    <!-- 第三种写法 多个类名 :class="{类名1:布尔值,类名2:布尔值}" 布尔值是true,这个类名就保留 如果是false 类名废弃 默认以后用这种 -->
    <div :class="{ a: flag1, b: flag2 }"></div>
  </div>
</template>

<script>
// 行内样式 只有一二个属性修饰 类名 一堆的属性 
export default {
  data () {
    return {
      class1: 'a',
      class2: 'b',
      flag1: true,
      flag2: false
    }
  },
}
</script>

<style scoped>
.a {
  width: 200px;
  height: 200px;
}
.b {
  background-color: pink;
}
</style>
