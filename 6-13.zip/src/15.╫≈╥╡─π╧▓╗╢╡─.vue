<template>
  <div>
    <label v-for="(item, index) in arr" :key="index">
      <input type="checkbox" v-model="selectedArr" :value="item" />{{ item }}
    </label>

    <ul>
      <li v-for="(item, index) in selectedArr" :key="index">
        {{ item }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data () {
    return {
      arr: ["科幻", "喜剧", "动漫", "冒险", "科技", "军事", "娱乐", "奇闻"],
      selectedArr: []//被选中的也要有一个数组
    }
  },
}
</script>

<style scoped>
</style>
