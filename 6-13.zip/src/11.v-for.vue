<template>
  <div>
    <ul>
      <li v-for="item in arr">
        {{ item }}
      </li>
    </ul>

    <hr />
    <ul>
      <li v-for="(item, index) in arr">{{ item }} -- {{ index }}</li>
    </ul>

    <hr />
    <ul>
      <li v-for="item in stuArr">
        {{ item.name }}
      </li>
    </ul>

    <hr />
    <li v-for="item in obj">
      {{ item }}
    </li>
  </div>
</template>

<script>
// 指令
// v-bind 属性
// v-on 事件 
// v-model 表单双向数据绑定 
// v-text 等价于{{}}
// v-html 用来渲染html字符串
// v-if
// v-show 
// v-for 
export default {
  data () {
    return {
      arr: ['blue', 'pink', 'red'],
      stuArr: [
        {
          id: 1001,
          name: "孙悟空",
          sex: "男",
          hobby: "吃桃子",
        },
        {
          id: 1002,
          name: "猪八戒",
          sex: "男",
          hobby: "背媳妇",
        },
      ],
      obj: {
        name: "小黑",
        age: 18,
        class: "1期",
      }
    }
  },
}

// var arr = ['blue', 'pink', 'red']
// arr.forEach((item,index)=>{

// })

// arr.forEach((item)=>{

// })

// arr.forEach((value)=>{

// })
</script>

<style scoped>
</style>
