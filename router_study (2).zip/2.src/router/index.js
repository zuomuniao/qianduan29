
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
//这个@符写法其实本质就是绝对路径，好处是当前文件换位置了，路径全部不用变
import Layout from '@/views/Layout'//这个一级路由没有必要懒加载
// import HangZhou from '@/views/HangZhou.vue'
// import WenZhou from '@/views/WenZhou.vue'
// import NanJing from '@/views/NanJing.vue'
// 懒加载写法
const HangZhou = () => import('@/views/HangZhou.vue')
const WenZhou = () => import('@/views/WenZhou.vue')
const NanJing = () => import('@/views/NanJing.vue')
const router = new VueRouter({
    // mode: 'history',
    routes: [
        { path: '/', redirect: '/zhejiang/hangzhou' },
        // { path: '/zhejiang/hangzhou', component: HangZhou },
        // { path: '/zhejiang/wenzhou', component: WenZhou }
        {
            // 我们把一样的视图代码提取到Layout中 把不一样放在children子路由视图就可以了
            path: '/zhejiang', component: Layout, children: [
                //这个就变成了相对写法 相对于父路由 
                // 'hangzhou' 等价于 /zhejiang/hangzhou 不能在前面加/
                {
                    path: 'hangzhou', component: HangZhou, meta: {
                        title: '杭州',

                    },
                    // beforeEnter(to,from,next){

                    // }
                },
                {
                    path: 'wenzhou', component: WenZhou, meta: {
                        title: '温州',
                    }
                }
            ]
        },
        { path: '/jiangsu/nanjing', component: NanJing },
        // {path:'*',component:NotFound}
    ]
})

// from 来自哪里 to 去哪 next 下一个  保安 
// 中间件 function(req,res,next)

//a->b 
//a --> 路由前置守卫 -> b 
// router.beforeEach((to, from, next) => {
//     document.title = to.meta.title
//     // to.path(不带查询参数的路径) to.fullPath(完整路径 带有查询参数)
//     // next三种写法
//     // 1. next() 放行 
//     // 2. next('/abc') 重定向到/abc这个url 
//     // 3. next(false) 阻止跳转
//     var isLogin = false //true代表用户登录成功 false登录失败 （账号密码错了）
//     // 如果用户想去登录，直接放行 如果想去的其他地方， 校验一下用户有没有登录 如果有 放行 如果没有 跳转到登录
//     if(to.path === '/login')return next()
//     if(isLogin){
//         next()
//     }else{
//         next('/login')
//     }
// })


// // 在前置地方开一个加载中,在后置把加载中关掉
// router.afterEach((to, from) => {

// })

export default router


// 路由文件如果换位置了，可能路由中所有的地址全部是错，

// 路由钩子 (实际项目中用得多的 beforeEach,afterEach,beforeRouteUpdate)
// 1. 全局钩子
//     + beforeEach
//     + afterEach
// 2. 路由独享钩子  只会对当前这个路由规则才有效果
//     + beforeEnter
// 3. 组件内钩子 a->b ->c
//     + beforeRouteEnter 进入这个组件之前
//     + beforeRouteUpdate 路由更新的时候触发
//     + beforeRouteLeave  离开这个路由的时候