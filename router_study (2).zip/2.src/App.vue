<template>
  <div>
    <router-link to="/zhejiang/hangzhou">hz</router-link>
    &nbsp;
    <router-link to="/zhejiang/wenzhou">wz</router-link>
    <hr />
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
