<template>
  <div>
    <!-- 在vue-router中有一个类似a标签一个组件，可以实现切换 -->
    <!-- from....to  -->
    <!-- tag="span" -->
    <router-link to="/login">login</router-link>
    &nbsp;
    <router-link to="/home">home</router-link>
    <!-- &nbsp;
    <router-link to="/home/abc">home-abc</router-link> -->
    <button @click="goHome">login</button>
    <hr />
    <!-- 路由占符位 -->
    <router-view></router-view>
  </div>
</template>

<script>
// 路由切换有两种
// 1. 声明式导航
// 2. 编程式导航
// router-link-active是自动生成的 你点击哪个router-link,哪个router-link就有这个类名

// router-link-active 模糊匹配 只要router-link中的to是属于路径的一部分就激活
// router-link-exact-active 精确匹配  to必须和url一模一样
export default {
  created () { },
  data () {
    return {}
  },
  methods: {
    goHome () {
      // this.$router.push('/home')
      // this.$router.push({ path: '/home' })
      // this.$router.push({ name: 'home', query: { id: 2 } })
      this.$router.push({ name: 'home', params: { id: 2 } })
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: {}
}



// console.log(123);
// console.log(123);

// var a = 123
// console.log(a);
// console.log(a);

</script>

<style scoped>
.router-link-active {
  color: red;
}
</style>
