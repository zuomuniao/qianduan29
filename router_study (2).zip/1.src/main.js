import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false
import router from './router'
new Vue({
  router,//这块是让路由对象和vue实例产生关系
  render: h => h(App),
}).$mount('#app')

// 路由
// 1. 得有2个以上组件
// 2. 得有映射表 
// 3. 占位符