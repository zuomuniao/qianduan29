// 1. 得有一个占位符
// 2. 得有二个以上的页面组件 (页面组件放在views或pages中)
// 3. 映射关系
// 登录页 Login 首页 Home

// 第一步、引入vue,vue-router,通过Vue.use来使用一下vue-router这个核心插件
import Vue from 'vue'
import VueRouter from 'vue-router'
// 在写项目的时候只有index.vue这个名字首字母小写的，并且只有1个单词， 
import Home from '../views/Home'
import Login from '../views/Login'
import NotFound from '../views/NotFound.vue'
//vue-router是vue的核心插件 插件怎么用?和以前node.js中express中间件类似 app.use()
Vue.use(VueRouter)

// 第二步、new出来一个路由对象
const router = new VueRouter({
    mode: 'history',//hash 默认值 带有#号 history 不带有#
    // 路由映射表 路由表 不同的url路径指向不同的组件
    // 每个映射规则就是一个对象
    routes: [
        //注意事项：path对就的url地址是自己随便写的，不能有大写字母 并且是以 /开头 因为是网络路径
        { path: '/', redirect: '/home' },//路由重定向
        { path: '/home', component: Home, name: 'home' },
        { path: '/home/abc', component: Home },
        { path: '/login', component: Login },
        // /home/1 /home/2 /home/3 
        { path: '/home/:id', component: Home },
        { path: '*', component: NotFound },//一般把*号路由写在最后面
    ]
})

// 第三步、把路由对象暴露出去
export default router


// router只有一个 路由对象
// routes 路则映射表 