<template>
  <div>
    首页
    <!-- {{ $route.query.id }} -->
    {{ $route.params.id }}
    <!-- go(-1) 微信  -->
    <button @click="$router.go(-1)">后退</button>
  </div>
</template>

<script>
export default {
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
