import Vue from 'vue'
import { Button, Cell, CellGroup, Col, Row } from 'vant';
Vue.use(Button);
Vue.use(Cell);
Vue.use(CellGroup);
Vue.use(Col);
Vue.use(Row);

// 在vue组件中使用 van- 注册的时候只写后面，并且首字母大写