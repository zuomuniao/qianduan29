mpa vs spa
mpa -> 多页面应用程序
spa -> 单页面应用程序

spa 的好处：用户体验更好了一点，节省用户手机流量

路由：url 地址不一样，得到不同的内容
前端路由：url 地址不一样，不同的组件就会到占位符中显示

接下来做的事情有点繁琐，但是其实只在学习练习的时候这么做

多页面应用 大事件
单页面应用 spa

前端路由

1. 只有一个 html
2. 有一个占位符 router-view
3. 二个以上页面组件 views(pages)
4. 配置路由规则表 路由表 映射 path(路径)和 component 组件的映射

参数有两种
url?id=2 查询参数 this.$route.query.id 
url/4 -> url/:id 路径参数 也可以称为动态路由匹配 this.$route.params.id

$route 路由表规则 具体的一条规则 一条路线  获取当前这条路线的参数 
$router 路径对象 百度地图

第一种 查询参数
routes:[
{path:'/home',component:Home}
]

url?id=2

{{$route.query.id}}

第二种 动态路由匹配 这种更好一点 代码更好维护

routes:[
{path:'/home/:id',component:Home}
]

url/2

{{$route.params.id}}

声明式导航 <a href>
编程式导航 location.href js 方式来跳转

$route 是代表的当前这一条路线轨迹 可以通过这个东西获取当前这个路线的参数 $route.params $route.query
$router 导航仪 可以实现路线切换 路由器 $router.push('/home')

我们为了代码可维护性，可以给路由起个名字 在具体代码通过 name 来访问，将来 path 变了，vue 文件不需要改

编程式导航

1. this.$router.push('/home')
2. this.$router.push({path:'/home'})
3. this.$router.push({name:'home'}) 配合 路由表中的路由规则必须起一个 name 属性 好处：维护性更强
4. 传参 this.$router.push({name:'home',query:{id:2},params:{id:2}})

历史记录：用户在同一个标签各种访问，会得到一个历史记录 类似数组 一开始是空数组
['/a','/b','/c']

this.$router.go(-2)

this.$router.push({name:'/home'})
this.$router.replace({name:'/home'}) 这个效果和 push 没有区别，但是它会导致历史记录数组清空了

this.$router.push
this.$router.go
this.$router.replace

什么时候用嵌套路由 当我们发现两个路由对应的组件有部分视图是一样的时候，就可以用嵌套路由来实现

1. 嵌套路由也可以称为是父子路由
2. 把一样的视图放在父路由中 然后把父路由视图放在一级路由占位符 (App.vue)
3. 接下来把父路由视图也放一个占位符 （二级路由占位符）
4. 子路由对应的视图就只需要写不一样的视图代码就行了，放在二级路由占位符

我们一般行业规范把一级路由视图会写在 Layout 文件夹中

/zhejiang/hangzhou
/zhejiang/wenzhou

正常一个 path 对应是一个 component 一对一的关系
但是也可以一对多 一个 path 对应 components 多个组件 多个 router-view

有很多路由规则 路线，我们从 A 路线到 B 路线，如果有前置路由守卫，在 A 到 B 之前，就会先进入守卫代码，可以进行校验 阻拦

1. 导航的方式
   - 声明式导航 `<a href="">` --> <router-link to>
     - 激活内置类名
       - router-link-active 模糊匹配 只要包含就有效果 /home/abc /home
       - router-link-exact-active 精确匹配 必须一模一样才有效果
   - 编程式导航
   * this.$router.push('/home')
   * this.$router.push({name:'/home',query:{},params:{}})
   - this.$router.push
   * this.$router.go(-1)
   - this.$router.back()
   * this.$router.replace

url?id=1 -> $route.query.id
url/1 -> url/:id -> $route.params.id

试错
$route 一条路线 
$router 只有一个 导航仪

嵌套路由

命名视图

next() 放行
next('/abc') 重定向
next(false) 阻止切换

vue2.0 vant@2.0 element ui (iview,ant design vue)
vue3.0 vant@3.0 element plus

在真正的项目中 自动按需引入 vant （好处是体积小 但是配置最麻烦的）
在学习的时候 全部导入（好处是简单，但是体积最大的）
在真正的项目中，65 个组件用了一大半 那也可以全部导入

组件的使用方式
第一步、先找到合适的组件
第二步、看右边演示效果找到和我们要的最匹配的，把代码 CV
第三步、去最下面的 api 中看 props,event,slots 主题定制 微调 调成和我们设计稿一模一样的
如果样式不一样，自己写样式覆盖 不生效 !important
