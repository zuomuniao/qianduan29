<template>
  <div>
    {{ $route.params.id }}
    {{ id }}
  </div>
</template>

<script>
// 动态路由匹配，如果路由切换，但是冒号后面改变，会导致组件的复用，也就会导致组件钩子函数(created)不会再执行了
// 解决办法有二种
// 1. 侦听器去侦听$route 
// 2. 使用组件内路由守卫beforeRouteUpdate 
export default {
  props: {
    id: {
      type: [String, Number]
    }
  },
  created () {
    console.log('ajax请求');
  },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  //   watch: {
  //     $route (newVal, oldVal) {
  //       console.log('ajax请求');
  //     }
  //   },
  filters: {},
  components: {},
  beforeRouteUpdate () {
    console.log('ajax请求');
  },
}
</script>

<style scoped>
</style>
