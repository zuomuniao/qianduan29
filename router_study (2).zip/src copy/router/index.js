
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
//Layout 模板父路由组件
const Home = () => import('@/views/Home')
const router = new VueRouter({
    routes: [
        // 复用
        { path: '/home/:id', component: Home, props: true },
        // {path:'url地址',component:组件,meta:元信息,name:给路由起个名字,redirect:重定向,children:子路由 嵌套路由,props:true}
    ]
})
export default router

// props只能父组件向子组件传值
// props还可以用来路由向页面组件传值