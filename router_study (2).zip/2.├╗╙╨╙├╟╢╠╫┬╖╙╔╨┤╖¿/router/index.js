
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
import HangZhou from '../views/HangZhou.vue'
import WenZhou from '../views/WenZhou.vue'
const router = new VueRouter({
    routes: [
        { path: '/', redirect: '/zhejiang/hangzhou' },
        { path: '/zhejiang/hangzhou', component: HangZhou },
        { path: '/zhejiang/wenzhou', component: WenZhou }
    ]
})

export default router

