<template>
  <div>
    <h1>Hello world</h1>
    <img src="./assets/logo.png" alt="" />
  </div>
</template>

<script>
export default {

}
</script>
