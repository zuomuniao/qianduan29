<template>
  <div>
    <button @click="fn">按钮</button>
    <p>{{ msg }}</p>
  </div>
</template>

<script>
// 数据驱动视图 
export default {
  data () {
    return {
      msg: 'hello world'
    }
  },
  methods: {
    fn () {
      this.msg = this.msg.split('').reverse().join('')
    }
  }
}
</script>

<style scoped>
</style>
