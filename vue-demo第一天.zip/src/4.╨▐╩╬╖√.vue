<template>
  <div>
    <!-- 事件修饰符 -->
    <!-- @事件类型.事件修饰符 -->
    <button @click.stop="fn">按钮</button>
    <a href="http://baidu.com" @click.prevent>百度一下</a>
    <button @click.once="fn">按钮一次性</button>
    <hr />
    <!-- input 按键修饰符 -->
    <input type="text" @keyup.13="fn2" />
    <input type="text" @keyup.enter="fn2" />
    <!-- esc代表的是清空的 -->
    <input type="text" @keyup.esc="fn3" />
  </div>
</template>

<script>
// 事件三个阶段：捕获 处于目标元素 冒泡 我们可以通过设置addEventLisener('click',callback,bool) false 
export default {
  methods: {
    fn () {
      alert('按钮被点击了')
    },
    fn1 () {
      alert('div被点击了')
    },
    fn2 () {
      console.log('enter被按了');
    },
    fn3 () {
      console.log('esc被按了');
    }
  }
}
</script>

<style scoped>
</style>
