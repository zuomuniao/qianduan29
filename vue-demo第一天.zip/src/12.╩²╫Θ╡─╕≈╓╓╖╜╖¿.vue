<template>
  <div>
    <button @click="fn">按钮</button>
    <p>{{ arr }}</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      arr: ['pink', 'blue', 'red']
    }
  },
  methods: {
    fn () {
      // 这些方法会直接修改原数组
      //   this.arr.push('yellow')
      //   this.arr.pop()
      //   this.arr.shift()
      //   this.arr.unshift('yellow')
      //   this.arr.sort()//字符串是按a-z排 ascii码
      //   this.arr.reverse()
      //   this.arr.splice(1, 1)//前面1是索引 后面1是数量 删除

      //   filter,concat,slice这三个由于api是返回一个新的数组，并不会影响原始的数组，所以要用赋值 覆盖掉旧的数组才能让视图更新
      //   this.arr = this.arr.filter(item => item.length > 3)


      // 避免如下的二种操作
      // 当你利用索引直接设置一个数组项时 不会导致视图的更新
      //   this.arr[1] = 'yellow'
      //   当你修改数组的长度时
      //   this.arr.length = 0

      // 有操作索引的需求可以这样写
      //   this.$set(数组,索引,新的值)
      //   this.$set(this.arr, 1, 'yellow')

      this.arr.splice(1, 1, 'yellow')//修改 (索引值,数量,修改之后新的值)

    }
  }
}
</script>

<style scoped>
</style>
