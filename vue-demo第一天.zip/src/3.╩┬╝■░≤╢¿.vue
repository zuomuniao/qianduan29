<template>
  <div>
    <!-- 函数体只有一行的时候才这样写 -->
    <button v-on:click="count++">按钮1</button>
    <button v-on:click="add">按钮2</button>
    <button v-on:click="addN(5)">按钮3</button>
    <hr />
    <button @click="count++">按钮1</button>
    <button @click="add">按钮2</button>
    <button @click="addN(5)">按钮3</button>

    <hr />
    <!-- 事件对象 -->
    <!-- 写法1：当事件回调后面没有小括号的时候，其实自动就把事件对象传到形参中 -->
    <!-- @click="fn"等价于 @click="fn($event)" -->
    <button @click="fn">按钮1</button>
    <!-- $event是固定写法 -->
    <button @click="fn1(2, $event)">按钮2</button>
    <!-- 写法二 函数本来就有参数的时候，就必须显式的用一个叫$event来传事件对象过去 -->
    <p>{{ count }}</p>
  </div>
</template>

<script>
// 不要发明 文档没有讲就是不行
// 在template中用data中数据直接用就行了，在methods中拿data中数据通过this来拿
export default {
  data () {
    return {
      count: 1,
    }
  },
  methods: {
    add () {
      this.count++
    },
    addN (num) {
      this.count += num
    },
    fn (e) {
      console.log(e);//事件对象
    },
    fn1 (num, e) {
      console.log(num);
      console.log(e);
    }
  }
}
</script>

<style scoped>
</style>
