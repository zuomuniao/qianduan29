<template>
  <div>
    <!-- a = a + 1 -> a++ -->
    <!-- v-model不用能不能实现双向数据绑定 -->
    <input type="text" v-model="msg" />
    <!-- v-model其实是 v-bind:value和@input的写法的语法糖 v-model的原理  -->
    <!-- v-bind:value="msg" -> 实现了数据变了，视图跟着变 -->
    <!-- @input="msg = $event.target.value" -> 视图变了，数据跟着变 -->
    <input type="text" v-bind:value="msg" @input="msg = $event.target.value" />
    <!-- lazy 懒  有时候我们可能觉得默认事件oninput太频繁了，就可以加上lazy修饰符 把oninput变成onchange 值改变并且失去焦点的时候 -->
    <input type="text" v-model.lazy="username" />
    <p>用户名的长度在检测是{{ username.length }}</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'hello world',
      username: ''
    }
  }
}

// 三种修饰符 
// 1. 事件修饰符 stop prevent once 
// 2. 按键修饰符 enter esc 
// 3. 表单修饰符 number trim lazy 
</script>

<style scoped>
</style>
