<template>
  <div>
    <p>{{ msg }}</p>
    <!-- 这个写法了解就行了，一般没有人用 -->
    <p v-text="msg"></p>
    <!-- vue看到要插入的是html片段，它就会把<变成 lt 把 > 变成 gt  -->
    <p>{{ msg1 }}</p>
    <!-- 如果vue看到用的是v-html,哪怕要插入的是html,它也会直接放行 -->
    <p v-html="msg1"></p>
  </div>
</template>

<script>
// xss攻击 网站做得不好的，直接用户在留言板写的是script脚本，可能就会有安全问题 所以正规都要处理这个问题，让html标签原样输出 
export default {
  data () {
    return {
      msg: 'hello world',
      //如果数据是来自自己公司的服务器，我们认为它是安全的 我们还是想让它直接变红色 加粗
      msg1: '<h1 style="color:red;">123</h1>'
    }
  },
}
</script>

<style scoped>
</style>
