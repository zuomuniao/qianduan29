<template>
  <div>
    <button @click="color = 'green'">按钮</button>
    <div :style="{ backgroundColor: color }"></div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      color: 'red',
    }
  }
}
</script>

<style scoped>
div {
  width: 200px;
  height: 200px;
}
</style>
