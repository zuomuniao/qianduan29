<template>
  <div>
    <!-- 在vue中，v-bind只能实现数据变了，视图跟着变，反过来是不行的 -->
    <!-- 在vue中，只有一个指令是双向的（数据->视图 视图->数据) v-model 
    限制：只能作用于表单控件 input,textarea,select  -->
    <!-- 单向的 -->
    <input type="text" v-bind:value="msg" />
    <!-- 双向的 -->
    <input type="text" v-model="msg" />
    <textarea v-model="msg"></textarea>
    <!-- select使用方式 select加v-model option要有value  -->
    <select v-model="value">
      <option value="0">吃饭</option>
      <option value="1">睡觉</option>
      <option value="2">打豆豆</option>
    </select>
    <!-- 单个复选框 值只有true或false -->
    <input type="checkbox" v-model="flag" />

    <br />
    <!-- 一组复选框 v-model绑定的值必须是一个数组 每个input必须绑定v-model 并且有一个不同的value值 -->
    sing<input type="checkbox" v-model="arr" value="sing" /> dance<input
      type="checkbox"
      v-model="arr"
      value="dance"
    />
    basketball<input type="checkbox" v-model="arr" value="basketball" />

    <hr />
    <!-- 单选框 多选一 一组 每个input必须绑定v-model 并且有不同的值 但是v-model值是字符串  -->
    <input type="radio" value="男" v-model="gender" />
    <input type="radio" value="女" v-model="gender" />

    <hr />
    <!-- v-model也有自己的修饰符 由于v-model只能用于表单元素，所以你也可以叫表单修饰符 -->
    <input type="text" v-model.number="value1" />
    <p>{{ value1 + 200 }}</p>

    <!-- trim修饰符可以去掉左边和右边的空格 -->
    <input type="text" v-model.trim="msg" />
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'hello world',
      value: '1',
      flag: true,
      arr: [],
      gender: '',
      value1: 100
    }
  }
}
</script>

<style scoped>
</style>
