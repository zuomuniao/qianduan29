<template>
  <tr>
    <td>
      <input type="checkbox" v-model="item.checked" />
    </td>
    <td>{{ item.name }}</td>
    <td>{{ item.price }}</td>
    <td>
      <button
        @click="item.num = item.num === 1 ? 1 : item.num - 1"
        :disabled="item.num <= 1"
      >
        -
      </button>
      <span>{{ item.num }}</span>
      <button @click="item.num++">+</button>
    </td>
    <td>{{ item.price * item.num }}</td>
    <td><button @click="goodList.splice(index, 1)">删除</button></td>
  </tr>
</template>

<script>
export default {
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
