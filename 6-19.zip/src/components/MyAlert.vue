<template>
  <div class="container">
    <h3>
      <slot name="title"></slot>
    </h3>
    <div>
      <!-- 占位符 内容不确定 插槽的默认值 如果没有传就用默认值 如果传了就用传过来的值 -->
      <slot name="content">出错了</slot>
    </div>
  </div>
</template>

<script>
export default {
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
.container {
  width: 400px;
  height: 300px;
  border: 1px solid blue;
  margin-bottom: 20px;
}

.container h3 {
  height: 28px;
  background-color: pink;
}
</style>
