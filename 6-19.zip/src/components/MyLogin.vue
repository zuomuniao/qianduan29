<template>
  <div>
    登录
    <input type="text" v-model="msg" />
    <p>当前组件被访问的时间是：{{ time }}</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'hello world',
      time: null
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {},
  // 操作结果： beforeDestroy  destroyed一次都不会执行 beforeCreate created beforeMount mounted只会执行一次 后面不会执行了
  // 初始化、挂载阶段只会执行一次，销毁一次都不会执行
  // 我们之前把代码写在created中是希望每次组件打开的时候要执行一次，但是现在缓存之后，这个created只会执行一次
  // keep-alive为了解决这个问题，引入了二个新的只有keep-alive才可以用的钩子函数 activated（只要组件被激活了） deactivated（组件没有激活 失活的时候执行） 
  //  activated -> 写之前放在created中的代码
  //  deactivated -> beforeDestroy 中的清理代码
  beforeCreate () {
    console.log('初始化之前');
  },
  created () {
    console.log('初始化之后');

  },
  beforeMount () {
    console.log('挂载前');
  },
  mounted () {
    console.log('挂载后');
  },
  beforeUpdate () {
    console.log('更新前');
  },
  updated () {
    console.log('更新后');
  },
  beforeDestroy () {
    console.log('销毁前');
  },
  destroyed () {
    console.log('销毁后');
  },
  activated () {
    console.log('被激活');
    this.time = new Date().toLocaleString()
  },
  deactivated () {
    console.log('被失活');
  }
}
</script>

<style scoped>
</style>
