<template>
  <!-- 底部 -->
  <div class="my-footer">
    <!-- 全选 -->
    <div class="custom-control custom-checkbox">
      <input
        v-model="all"
        type="checkbox"
        class="custom-control-input"
        id="footerCheck"
      />
      <label class="custom-control-label" for="footerCheck">全选</label>
    </div>
    <!-- 合计 -->
    <div>
      <span>合计:</span>
      <span class="price">¥ {{ totalPrice }}</span>
    </div>
    <!-- 按钮 -->
    <button type="button" class="footer-btn btn btn-primary">
      结算 ( {{ totalNum }} )
    </button>
  </div>
</template>

<script>
export default {
  props: {
    list: {
      type: Array,
      required: true
    }
  },
  computed: {
    totalPrice () {
      //只勾选算在里面
      return this.list.reduce((sum, item) => {
        if (item.goods_state) {
          sum += item.goods_price * item.goods_count
        }
        return sum
      }, 0)
    },
    totalNum () {
      return this.list.reduce((sum, item) => {
        if (item.goods_state) {
          sum += item.goods_count
        }
        return sum
      }, 0)
    },
    all: {
      // list每一项是一个对象，我修改是对象的属性，没有改变对象的地址，所以还是只读的
      // 基本数据类型如果是props一定要用子向父传值，复杂类型可以直接修改属性，只要不改变地址就行了
      get () {
        return this.list.every(item => item.goods_state)
      },
      set (newVal) {
        this.list.forEach(item => item.goods_state = newVal)
      }
    }
  }
}
</script>

<style lang="less" scoped>
.my-footer {
  position: fixed;
  z-index: 2;
  bottom: 0;
  width: 100%;
  height: 50px;
  border-top: 1px solid #ccc;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 10px;
  background: #fff;

  .price {
    color: red;
    font-weight: bold;
    font-size: 15px;
  }
  .footer-btn {
    min-width: 80px;
    height: 30px;
    line-height: 30px;
    border-radius: 25px;
    padding: 0;
  }
}
</style>