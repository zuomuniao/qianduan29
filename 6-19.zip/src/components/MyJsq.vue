<template>
  <div id="app">
    <h2>测试题</h2>
    <MySubject v-for="item in list" :key="item.id" :item="item"></MySubject>
    <div>
      <MyFlag v-for="item in list" :key="item.id" :item="item"></MyFlag>
    </div>
  </div>
</template>

<script>
import MyFlag from './MyFlag.vue'
import MySubject from './MySubject.vue'
export default {
  components: {
    MySubject,
    MyFlag
  },
  created () {
    for (var i = 0; i < 5; i++) {
      this.generate()
    }
  },
  data () {
    return {
      list: []
    }
  },
  methods: {
    generate () {
      var num1 = Math.floor(Math.random() * 51)
      var num2 = Math.floor(Math.random() * 51)
      var id = this.list.length === 0 ? 1 : this.list[this.list.length - 1].id + 1
      this.list.push({
        id,
        num1,
        num2,
        status: 0//约定 0代表的未完成 1代表正确 2代表错误
      })
    }
  }
};
</script>

<style>
body {
  background-color: #eee;
}

#app {
  background-color: #fff;
  width: 500px;
  margin: 50px auto;
  box-shadow: 3px 3px 3px rgba(0, 0, 0, 0.5);
  padding: 2em;
}
</style>