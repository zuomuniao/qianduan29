<template>
  <div>
    <h3>test组件</h3>
    <p><slot :flag="flag" money="5000"></slot></p>
  </div>
</template>

<script>
// 5000
// 组件在data中有一个数据，但是不确定怎么展示
// 作用域插槽：带有数据的插槽
export default {
  created () { },
  data () {
    return {
      flag: true
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
