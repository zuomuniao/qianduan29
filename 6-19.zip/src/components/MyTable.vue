<template>
  <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col" v-for="(item, index) in headers" :key="index">
          {{ item }}
        </th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(item, index) in data" :key="index">
        <slot :index="index" :row="item"></slot>
      </tr>
    </tbody>
  </table>
</template>

<script>
// 1. 一块地方内容不确定 -> 插槽 <slot></slot>
// 2. 自己有数据 但是不知道怎么呈现 就用作用域插槽  true false -> 完成 未完成 
// flag:true 呈现方式 子组件把钱给父组件,父组件自己买东西
export default {
  props: {
    headers: {
      type: Array,
      required: true
    },
    data: {
      type: Array,
      required: true
    }
  },
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
