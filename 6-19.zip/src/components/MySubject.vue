<template>
  <div class="subject">
    <span>{{ item.num1 }}</span>
    <span>+</span>
    <span>{{ item.num2 }}</span>
    <span>=</span>
    <input type="number" v-model.number="sum" />
    <button :disabled="flag" @click.once="fn">提交</button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      sum: 0,
      flag: false
    }
  },
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  methods: {
    fn () {
      this.item.status = this.item.num1 + this.item.num2 === this.sum
      this.flag = true
    }
  }
};
</script>

<style scoped>
.subject {
  margin: 5px;
  padding: 5px;
  font-size: 20px;
}
.subject span {
  display: inline-block;
  text-align: center;
  width: 20px;
}
.subject input {
  width: 50px;
  height: 20px;
}
</style>