<template>
  <span
    >{{ item.id }}:
    <i v-if="item.status === 0">未完成</i>
    <i v-else-if="item.status === 1">正确</i>
    <i v-else>错误</i>
  </span>
</template>

<script>
export default {
  props: {
    item: {
      type: Object,
      required: true
    }
  }
};
</script>

<style scoped>
.right {
  color: green;
}
.error {
  color: red;
}
.undo {
  color: #ccc;
}
</style>