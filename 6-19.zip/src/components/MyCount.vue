<template>
  <div class="my-counter">
    <button
      type="button"
      class="btn btn-light"
      :disabled="obj.goods_count === 1"
      @click="obj.goods_count--"
    >
      -
    </button>
    <input
      type="number"
      class="form-control inp"
      v-model.number="obj.goods_count"
    />
    <button type="button" class="btn btn-light" @click="obj.goods_count++">
      +
    </button>
  </div>
</template>

<script>
export default {
  props: {
    obj: {
      type: Object,
      required: true
    }
  },
  watch: {
    // obj: {
    //   deep: true,//对象必须用deep:true 深度侦听
    //   // immediate:true,//侦听器默认第一次不会执行，加了这个之后打开页面就会执行
    //   handler (newVal) {
    //     if (newVal.goods_count < 1) {
    //       this.obj.goods_count = 1
    //     }
    //   }
    // }
    'obj.goods_count': function (newVal) {
      if (newVal < 1) {
        this.obj.goods_count = 1
      }
    }
  }
}
</script>

<style lang="less" scoped>
.my-counter {
  display: flex;
  .inp {
    width: 45px;
    text-align: center;
    margin: 0 10px;
  }
  .btn,
  .inp {
    transform: scale(0.9);
  }
}
</style>