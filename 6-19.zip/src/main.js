import Vue from 'vue'
import App from './App.vue'
import 'bootstrap/dist/css/bootstrap.css'
Vue.config.productionTip = false

import axios from 'axios'
axios.defaults.baseURL = 'https://www.escook.cn/'
// 把axios作为父类原型上的属性 所有的vue组件都可以访问到
Vue.prototype.$axios = axios

// v-abc 指令都是以v- v-model v-bind 
{/* <div v-abc></div> */ }
Vue.directive('color', {
  // 插入 el->element 元素 指令在谁身上，el就是谁
  // inserted 钩子函数 自动执行 当前所在的元素插入到DOM树中的时候执行
  inserted (el) {
    el.style.color = 'red'
  }
})

new Vue({
  render: h => h(App),
}).$mount('#app')
