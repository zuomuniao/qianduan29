<template>
  <div>
    <!-- 标准写法 -->
    <MyAlert>
      <!-- v-slot:用哪个插槽的名字 -->
      <template v-slot:title>标题1111</template>
      <template v-slot:content>内容1111</template>
    </MyAlert>

    <!-- 缩写 简写 -->
    <MyAlert>
      <!-- v-slot:用哪个插槽的名字 -->
      <template #title>
        <span>标题1111</span>
      </template>
      <template #content>内容1111</template>
    </MyAlert>

    <!-- 废弃的语法 -->
    <MyAlert>
      <!-- v-slot:用哪个插槽的名字 -->
      <span slot="title">标题1111</span>
      <div slot="content">内容1111</div>
    </MyAlert>

    <hr />
    <MyTest>
      <!-- v-slot:default 这个default可以不写 -->
      <template v-slot="obj">
        {{ obj.flag ? "真" : "假" }}
        {{ obj.money > 3000 ? "苹果" : "小米" }}
      </template>
    </MyTest>

    <MyTest>
      <!-- v-slot:default 这个default可以不写 -->
      <!-- 一般接收子组件中作用域插槽数据对象一般叫scope  -->
      <!-- 现在的组件都是自己封装,未来组件都是现成的第三方的 -->
      <!-- 只要会用插槽 -->
      <template v-slot="scope">
        <span style="color: green" v-if="scope.flag === true">正确</span>
        <span style="color: red" v-else>错误</span>
        {{ scope.money > 4000 ? "笔记本" : "蓝牙耳机" }}
      </template>
    </MyTest>

    <MyTest>
      <!-- v-slot:default 这个default可以不写 -->
      <template v-slot="{ flag, money }">
        <span style="color: green" v-if="flag === true">正确</span>
        <span style="color: red" v-else>错误</span>
        {{ money > 4000 ? "笔记本" : "蓝牙耳机" }}
      </template>
    </MyTest>
  </div>
</template>

<script>
// 子组件有一个数据要显示，但是呈现方式不确定，这个时候就可以用作用域插槽，把数据干脆传到外面，由父组件自己决定呈现方式
// #插槽 @事件 :属性 
import MyAlert from './components/MyAlert.vue'
import MyTest from './components/MyTest.vue'
export default {
  components: { MyAlert, MyTest }
}
</script>

<style scoped>
</style>

