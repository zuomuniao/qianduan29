<template>
  <div>
    <!-- 一堆组件但是只显示一个的时候，用v-if v-else来写太麻烦了，这个时候就可以用到动态组件 -->
    <!-- <MyLogin v-if="active === 'MyLogin'"></MyLogin>
    <MyHome v-else></MyHome> -->
    <!-- 这个地方必须有一个组件，但是将来这个组件是谁，不确定或者组件有可能一开始是A组件，后面变成了B组件 -->
    <!-- 占位符  -->
    <button @click="change">按钮</button>
    <!-- keep-alive 不加的话，动态组件切换的时候，组件会被销毁，如果加了，不会被销毁 有缓存 -->
    <!-- include 指定哪些组件需要缓存 包含 100个组件中只有1个组件或者2个组件需要缓存 -->
    <!-- exclude  指定哪些组件不需要缓存 不包含 排除 100个组件只有个别组件要缓存 -->
    <keep-alive :include="['MyLogin']">
      <component :is="active"></component>
    </keep-alive>
  </div>
</template>

<script>
// vue内置组件
// 1. template 
// 2. component 
// 3. keep-alive 
import MyLogin from './components/MyLogin.vue'
import MyHome from './components/MyHome.vue'
export default {
  created () { },
  data () {
    return {
      active: 'MyLogin'
    }
  },
  methods: {
    change () {
      if (this.active === 'MyLogin') {
        this.active = 'MyHome'
      } else {
        this.active = 'MyLogin'
      }
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: { MyLogin, MyHome }
}
</script>

<style scoped>
</style>
