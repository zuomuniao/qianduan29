<template>
  <div>
    <!-- <input type="text" ref="myInput" /> -->
    <p v-color>123</p>
    <div v-color>234</div>
  </div>
</template>

<script>
// 100个组件,每个组件中都有一个input,打开组件必须要获取焦点 --> 复用性操作DOM -> 搞一个自定义指令
// 页面中有一堆地方要做同样的DOM操作 -> 自定义指令
export default {

}


// 写出来所有在组件对象中属性
// 写每个属性作用用途 写一个例子
</script>

<style scoped>
</style>
