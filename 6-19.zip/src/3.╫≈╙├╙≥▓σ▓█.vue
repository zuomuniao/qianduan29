<template>
  <div class="container">
    <MyTable :data="list" :headers="headers">
      <template v-slot="scope">
        <td>{{ scope.index + 1 }}</td>
        <td>{{ scope.row.name }}</td>
        <td>{{ scope.row.age }}</td>
        <td>{{ scope.row.headImgUrl }}</td>
      </template>
    </MyTable>

    <MyTable :headers="headers1" :data="list1">
      <template v-slot="scope">
        <td>{{ scope.index + 1 }}</td>
        <td>{{ scope.row.flag ? "完成" : "未完成" }}</td>
        <td>{{ scope.row.name }}</td>
      </template>
    </MyTable>
  </div>
</template>

<script>
import MyTable from './components/MyTable.vue'
export default {
  created () { },
  data () {
    return {
      list: [
        {
          name: "小传同学",
          age: 18,
          headImgUrl:
            "http://yun.itheima.com/Upload/./Images/20210303/603f2d2153241.jpg",

        },
        {
          name: "小黑同学",
          age: 25,
          headImgUrl:
            "http://yun.itheima.com/Upload/./Images/20210304/6040b101a18ef.jpg",
        },
        {
          name: "智慧同学",
          age: 21,
          headImgUrl:
            "http://yun.itheima.com/Upload/./Images/20210302/603e0142e535f.jpg",
        },
      ],
      headers: ['名字', '年龄', '头像'],
      list1: [
        { name: '吃饭', flag: true },
        { name: '睡觉', flag: false },
        { name: '打豆豆', flag: true }
      ],
      headers1: ['状态', '任务名',]
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {
    MyTable
  }
}
</script>

<style scoped>
</style>
